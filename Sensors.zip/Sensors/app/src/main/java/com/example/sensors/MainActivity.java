package com.example.sensors;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity implements SensorEventListener {


    SensorManager sensormanager;
    private Sensor accelerometer, gyro, gravity, linearacc;
    private Sensor proximity, light, magnetic, pressure, temperature;

    TextView xaccelmax, yaccelmax, zaccelmax,xaccelmin,yaccelmin, zaccelmin, xaccelcur, yaccelcur, zaccelcur;
    TextView xgyromax, ygyromax, zgyromax, xgyromin, ygyromin, zgyromin, xgyrocur, ygyrocur,zgyrocur;
    TextView xmagmax, ymagmax, zmagmax, xmagmin, ymagmin, zmagmin, xmagcur, ymagcur, zmagcur;
    TextView xlinmax, ylinmax, zlinmax, xlinmin, ylinmin, zlinmin,xlincur, ylincur, zlincur;
    TextView xgramax, ygramax, zgramax, xgramin, ygramin, zgramin, xgracur, ygracur, zgracur;
    TextView xproxmax, xproxmin, xproxcur, xlightmax, xlightmin, xlightcur, xtemp, xpressure;
    private float currentx, currenty, currentz;
    static float lastxmin = 0.0f;
    static float lastymin = 0.0f;
    static float lastzmin = 0.0f;
    static float lastxmax = 0.0f;
    static float lastymax = 0.0f;
    static float lastzmax = 0.0f;

    static float lastxaccelmin = 0.0f;
    static float lastyaccelmin = 0.0f;
    static float lastzaccelmin = 0.0f;
    static float lastxaccelmax = 0.0f;
    static float lastyaccelmax = 0.0f;
    static float lastzaccelmax = 0.0f;

    static float lastgyroxmin = 0.0f;
    static float lastgyroymin = 0.0f;
    static float lastgyrozmin = 0.0f;
    static float lastgyroxmax = 0.0f;
    static float lastgyroymax = 0.0f;
    static float lastgyrozmax = 0.0f;


    static float lastmagxmin = 0.0f;
    static float lastmagymin = 0.0f;
    static float lastmagzmin = 0.0f;
    static float lastmagxmax = 0.0f;
    static float lastmagymax = 0.0f;
    static float lastmagzmax = 0.0f;


    static float lastgraxmin = 0.0f;
    static float lastgraymin = 0.0f;
    static float lastgrazmin = 0.0f;
    static float lastgraxmax = 0.0f;
    static float lastgraymax = 0.0f;
    static float lastgrazmax = 0.0f;


    static float lastlinxmin = 0.0f;
    static float lastlinymin = 0.0f;
    static float lastlinzmin = 0.0f;
    static float lastlinxmax = 0.0f;
    static float lastlinymax = 0.0f;
    static float lastlinzmax = 0.0f;


    static float lastproxmax;
    static float lastproxmin;

    static float lastligxmax;
    static float lastligxmin;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);



        //Accelerometer textviews
        xaccelmax = (TextView)findViewById(R.id.xaccelmax);
        yaccelmax = (TextView)findViewById(R.id.yaccelmax);
        zaccelmax = (TextView)findViewById(R.id.zaccelmax);
        xaccelmin = (TextView)findViewById(R.id.xaccelmin);
        yaccelmin = (TextView)findViewById(R.id.yaccelmin);
        zaccelmin = (TextView)findViewById(R.id.zaccelmin);
        xaccelcur = (TextView)findViewById(R.id.xaccelcur);
        yaccelcur = (TextView)findViewById(R.id.yaccelcur);
        zaccelcur = (TextView)findViewById(R.id.zaccelcur);

        //Gyroscope textviews
        xgyromax  = (TextView)findViewById(R.id.xgyromax);
        ygyromax  = (TextView)findViewById(R.id.ygyromax);
        zgyromax  = (TextView)findViewById(R.id.zgyromax);
        xgyromin  = (TextView)findViewById(R.id.xgyromin);
        ygyromin  = (TextView)findViewById(R.id.ygyromin);
        zgyromin  = (TextView)findViewById(R.id.zgyromin);
        xgyrocur  = (TextView)findViewById(R.id.xgyrocur);
        ygyrocur  = (TextView)findViewById(R.id.ygyrocur);
        zgyrocur  = (TextView)findViewById(R.id.zgyrocur);

        //Magnetometer textviews
        xmagmax  = (TextView)findViewById(R.id.xmagmax);
        ymagmax  = (TextView)findViewById(R.id.ymagmax);
        zmagmax  = (TextView)findViewById(R.id.zmagmax);
        xmagmin  = (TextView)findViewById(R.id.xmagmin);
        ymagmin  = (TextView)findViewById(R.id.ymagmin);
        zmagmin  = (TextView)findViewById(R.id.zmagmin);
        xmagcur  = (TextView)findViewById(R.id.xmagcur);
        ymagcur  = (TextView)findViewById(R.id.ymagcur);
        zmagcur  = (TextView)findViewById(R.id.zmagcur);

        //Linear accelerometer textviews
        xlinmax  = (TextView)findViewById(R.id.xlinmax);
        ylinmax  = (TextView)findViewById(R.id.ylinmax);
        zlinmax  = (TextView)findViewById(R.id.zlinmax);
        xlinmin  = (TextView)findViewById(R.id.xlinmin);
        ylinmin  = (TextView)findViewById(R.id.ylinmin);
        zlinmin  = (TextView)findViewById(R.id.zlinmin);
        xlincur  = (TextView)findViewById(R.id.xlincur);
        ylincur  = (TextView)findViewById(R.id.ylincur);
        zlincur  = (TextView)findViewById(R.id.zlincur);

        //Gravity textviews
        xgramax  = (TextView)findViewById(R.id.xgramax);
        ygramax  = (TextView)findViewById(R.id.ygramax);
        zgramax  = (TextView)findViewById(R.id.zgramax);
        xgramin  = (TextView)findViewById(R.id.xgramin);
        ygramin  = (TextView)findViewById(R.id.ygramin);
        zgramin  = (TextView)findViewById(R.id.zgramin);
        xgracur  = (TextView)findViewById(R.id.xgracur);
        ygracur  = (TextView)findViewById(R.id.ygracur);
        zgracur  = (TextView)findViewById(R.id.zgracur);

        //Proximity textviews
        xproxmax  = (TextView)findViewById(R.id.xproxmax);
        xproxmin  = (TextView)findViewById(R.id.xproxmin);
        xproxcur  = (TextView)findViewById(R.id.xproxcur);

        //Light sensor
        xlightmax = (TextView)findViewById(R.id.xlightmax);
        xlightmin = (TextView)findViewById(R.id.xlightmin);
        xlightcur = (TextView)findViewById(R.id.xlightcur);

        //Temperature
        xtemp = (TextView)findViewById(R.id.xtemp);

        //Pressure
        xpressure = (TextView)findViewById(R.id.xpressure);

        sensormanager = (SensorManager)getSystemService(Context.SENSOR_SERVICE);
        accelerometer = sensormanager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
        gyro = sensormanager.getDefaultSensor(Sensor.TYPE_GYROSCOPE);
        gravity = sensormanager.getDefaultSensor(Sensor.TYPE_GRAVITY);
        magnetic = sensormanager.getDefaultSensor(Sensor.TYPE_MAGNETIC_FIELD);
        linearacc = sensormanager.getDefaultSensor(Sensor.TYPE_LINEAR_ACCELERATION);
        proximity = sensormanager.getDefaultSensor(Sensor.TYPE_PROXIMITY);
        light = sensormanager.getDefaultSensor(Sensor.TYPE_LIGHT);
        pressure = sensormanager.getDefaultSensor(Sensor.TYPE_PRESSURE);
        temperature = sensormanager.getDefaultSensor(Sensor.TYPE_AMBIENT_TEMPERATURE);

    }

    @Override
    public void onSensorChanged(SensorEvent sensorEvent) {
       float[] values = sensorEvent.values;
       Sensor sensor = sensorEvent.sensor;
       String str;


       currentx = sensorEvent.values[0];
       currenty = sensorEvent.values[1];
       currentz = sensorEvent.values[2];


//       if(lastxaccelmax == 0.0){
//           lastxaccelmax = currentx;
//       }
//       if(lastxaccelmin == 0.0){
//           lastxaccelmin = currentx;
////       }
//       if(lastligxmin == 0.0){
//           lastligxmin = currentx;
//       }

//        if(lastproxmin == 0){
//            lastproxmin = currentx;
//        }

       // If the sensor is accelerometer
       if(sensor.getType() == Sensor.TYPE_ACCELEROMETER){

           str = String.format("%.2f", values[0]);
           xaccelcur.setText("X: "+ str);
           str = String.format("%.2f", values[1]);
           yaccelcur.setText("Y: "+ str);
           str = String.format("%.2f", values[2]);
           zaccelcur.setText("Z: "+ str);

           //Finding Max and Min values of various coordinates
          if (currentx > lastxaccelmax){
              str = String.format("%.2f", values[0]);
              xaccelmax.setText("X: "+ str);
              lastxaccelmax = currentx;
          }
          if (currentx < lastxaccelmin){
              str = String.format("%.2f", values[0]);
              xaccelmin.setText("X: "+ str);
              lastxaccelmin = currentx;
          }

//           //Y coordinates
           if (currenty > lastyaccelmax){
               str = String.format("%.2f", values[1]);
               yaccelmax.setText("  Y: "+ str);
               lastyaccelmax = currenty;
           }

           if (currenty < lastyaccelmin){
               str = String.format("%.2f", values[1]);
               yaccelmin.setText("  Y: "+ str);
               lastyaccelmin = currenty;
           }
           //Z coordinates
           if (currentz > lastzaccelmax){
               str = String.format("%.2f", values[2]);
               zaccelmax.setText(" Z: "+ str);
               lastzaccelmax = currentz;
           }

           if (currentz < lastzaccelmin){
               str = String.format("%.2f", values[2]);
               zaccelmin.setText(" Z: "+ str);
               lastzaccelmin = currentz;
           }
       }

       if(sensor.getType() == Sensor.TYPE_GYROSCOPE){
           str = String.format("%.2f", values[0]);
           xgyrocur.setText("X: "+ str);
           str = String.format("%.2f", values[1]);
           ygyrocur.setText("Y: "+ str);
           str = String.format("%.2f", values[2]);
           zgyrocur.setText("Z: "+ str);
           //Finding Max and Min values of various coordinates
               if (currentx > lastgyroxmax){
                   str = String.format("%.2f", values[0]);
                   xgyromax.setText("X: "+ str);
                   lastgyroxmax = currentx;
               }
               if (currentx < lastgyroxmin){
                   str = String.format("%.2f", values[0]);
                   xgyromin.setText("X: "+ str);
                   lastgyroxmin = currentx;
               }

               //Y coordinates
               if (currenty > lastgyroymax){
                   str = String.format("%.2f", values[1]);
                   ygyromax.setText("  Y: "+ str);
                   lastgyroymax = currenty;
               }

               if (currenty < lastgyroymin){
                   str = String.format("%.2f", values[1]);
                   ygyromin.setText("  Y: "+ str);
                   lastgyroymin = currenty;
               }
               //Z coordinates
               if (currentz > lastgyrozmax){
                   str = String.format("%.2f", values[2]);
                   zgyromax.setText(" Z: "+ str);
                   lastgyrozmax = currentz;
               }

               if (currentz < lastgyrozmin){
                   str = String.format("%.2f", values[2]);
                   zgyromin.setText(" Z: "+ str);
                   lastgyrozmin = currentz;
               }

       }

       if(sensor.getType() == Sensor.TYPE_MAGNETIC_FIELD){

           str = String.format("%.2f", values[0]);

           xmagcur.setText("X: "+ str);
           str = String.format("%.2f", values[1]);
           ymagcur.setText("Y: "+ str);
           str = String.format("%.2f", values[2]);
           zmagcur.setText("Z: "+ str);
           //Finding Max and Min values of various coordinates
           if (currentx > lastmagxmax){
               str = String.format("%.2f", values[0]);
               xmagmax.setText("X: "+ str);
               lastmagxmax = currentx;
           }
           if (currentx < lastmagxmin){
               str = String.format("%.2f", values[0]);
               xmagmin.setText("X: "+ str);
               lastmagxmin = currentx;
           }
           //Y coordinates
           if (currenty > lastmagymax){
               str = String.format("%.2f", values[1]);
               ymagmax.setText("  Y: "+ str);
               lastmagymax = currenty;
           }

           if (currenty < lastmagymin){
               str = String.format("%.2f", values[1]);
               ymagmin.setText("  Y: "+ str);
               lastmagymin = currenty;
           }
           //Z coordinates
           if (currentz > lastmagzmax){
               str = String.format("%.2f", values[2]);
               zmagmax.setText(" Z: "+ str);
               lastmagzmax = currentz;
           }

           if (currentz < lastmagzmin){
               str = String.format("%.2f", values[2]);
               zmagmin.setText(" Z: "+ str);
               lastmagzmin = currentz;
           }
       }

       if(sensor.getType() == Sensor.TYPE_LINEAR_ACCELERATION){
           str = String.format("%.2f", values[0]);
           xlincur.setText("X: "+ str);
           str = String.format("%.2f", values[1]);
           ylincur.setText("Y: "+ str);
           str = String.format("%.2f", values[2]);
           zlincur.setText("Z: "+ str);
           if (currentx > lastlinxmax){
               str = String.format("%.2f", values[0]);
            xlinmax.setText("X: "+ str);
            lastlinxmax = currentx;
        }

        if (currentx < lastlinxmin){
            str = String.format("%.2f", values[0]);
            xlinmin.setText("X: "+ str);
            lastlinxmin = currentx;
        }
        //Y coordinates
        if (currenty > lastlinymax){
            str = String.format("%.2f", values[1]);
            ylinmax.setText("  Y: "+ str);
            lastlinymax = currenty;
        }

        if (currenty < lastlinymin){
            str = String.format("%.2f", values[1]);
            ylinmin.setText("  Y: "+ str);
            lastlinymin = currenty;
        }
        //Z coordinates
        if (currentz > lastlinzmax){
            str = String.format("%.2f", values[2]);
            zlinmax.setText(" Z: "+ str);
            lastlinzmax = currentz;
        }

        if (currentz < lastlinzmin){
            str = String.format("%.2f", values[2]);
            zlinmin.setText(" Z: "+ str);
            lastlinzmin = currentz;
        }
    }

       if(sensor.getType() == Sensor.TYPE_GRAVITY){
           str = String.format("%.2f", values[0]);
           xgracur.setText("X: "+ str);
           str = String.format("%.2f", values[1]);
           ygracur.setText("Y: "+ str);
           str = String.format("%.2f", values[2]);
           zgracur.setText("Z: "+ str);
           if (currentx > lastgraxmax){
               str = String.format("%.2f", values[0]);
               xgramax.setText("X: "+ str);
               lastgraxmax = currentx;
           }
           if (currentx < lastgraxmin){
               str = String.format("%.2f", values[0]);
               xgramin.setText("X: "+ str);

               lastgraxmin = currentx;
           }
           //Y coordinates
           if (currenty > lastgraymax){
               str = String.format("%.2f", values[1]);
               ygramax.setText("  Y: "+ str);
               lastgraymax = currenty;
           }

           if (currenty < lastgraymin){
               str = String.format("%.2f", values[1]);
               ygramin.setText("  Y: "+ str);
               lastgraymin = currenty;
           }
           //Z coordinates
           if (currentz > lastgrazmax){
               str = String.format("%.2f", values[2]);
               zgramax.setText(" Z: "+ str);
               lastgrazmax = currentz;
           }

           if (currentz < lastgrazmin){
               str = String.format("%.2f", values[2]);
               zgramin.setText(" Z: "+ str);
               lastgrazmin = currentz;
           }
       }

       if(sensor.getType() == Sensor.TYPE_PROXIMITY) {

           xproxcur.setText("X: "+ String.valueOf(currentx));

           if (currentx > lastproxmax) {

               xproxmax.setText("X: " + String.valueOf(values[0]));
               lastproxmax = currentx;
           }
           if (currentx <= lastproxmin) {
               xproxmin.setText("X: " + String.valueOf(values[0]));
               lastproxmin = currentx;
           }
       }
       if(sensor.getType() == Sensor.TYPE_LIGHT) {

           xlightcur.setText("X: "+ String.valueOf(currentx));

           if (currentx > lastligxmax) {

               xlightmax.setText("X: " + String.valueOf(values[0]));
               lastligxmax = currentx;
           }
           if (currentx <= lastligxmin) {
               xlightmin.setText("X: " + String.valueOf(values[0]));
               lastligxmin = currentx;
           }

       }
    }


    public void onResume(){
      super.onResume();
      if(accelerometer != null){
          sensormanager.registerListener(this, accelerometer, SensorManager.SENSOR_DELAY_NORMAL);
      }

      if(gyro != null) {
          sensormanager.registerListener(this, gyro, SensorManager.SENSOR_DELAY_NORMAL);
      }

      if(magnetic != null){
          sensormanager.registerListener(this, magnetic, SensorManager.SENSOR_DELAY_NORMAL);
      }

      if(linearacc != null) {
          sensormanager.registerListener(this, linearacc, SensorManager.SENSOR_DELAY_NORMAL);
      }

      if(gravity != null) {
          sensormanager.registerListener(this, gravity, SensorManager.SENSOR_DELAY_NORMAL);
      }

      if(proximity != null) {
         sensormanager.registerListener(this, proximity, SensorManager.SENSOR_DELAY_NORMAL);
      }

      if(light != null) {
          sensormanager.registerListener(this, light, SensorManager.SENSOR_DELAY_NORMAL);
      }

      if(temperature != null) {
          sensormanager.registerListener(this, temperature, SensorManager.SENSOR_DELAY_NORMAL);
      } else {
          xtemp.setText("Temperature sensor not present");
      }

      if(pressure != null) {
         sensormanager.registerListener(this, pressure, SensorManager.SENSOR_DELAY_NORMAL);
      } else {
         xpressure.setText("Pressure sensor not present");
      }
    }

    public void onPause(){
        super.onPause();
        sensormanager.unregisterListener(this);
    }


    @Override
    public void onAccuracyChanged(Sensor sensor, int i) {

    }
}
