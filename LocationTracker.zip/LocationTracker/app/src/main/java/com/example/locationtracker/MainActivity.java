package com.example.locationtracker;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.text.Html;
import android.widget.TextView;
import android.widget.Toast;

import java.io.IOException;
import java.util.List;

public class MainActivity extends AppCompatActivity implements LocationListener, SensorEventListener {

    TextView text, avg_text;
    float x;
    SensorManager sensormanager;
    private Sensor light;
    double init_lat;
    double init_long;
    float init_sensor_value;
    int counter;
    LocationManager locationManager;
    boolean GPSEnabled;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        text = (TextView) findViewById(R.id.latitude);
        avg_text = (TextView)findViewById(R.id.average);
        sensormanager = (SensorManager)getSystemService(Context.SENSOR_SERVICE);
        light = sensormanager.getDefaultSensor(Sensor.TYPE_LIGHT);

        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            Toast.makeText(this, "Permission denied", Toast.LENGTH_SHORT).show();

        }
        ActivityCompat.requestPermissions(MainActivity.this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, 123);
        locationManager = (LocationManager)getSystemService(Context.LOCATION_SERVICE);
        GPSEnabled = locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER);

        counter = 0;

//        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
//            Toast.makeText(this, "Permission denied", Toast.LENGTH_SHORT).show();
//
//        }
        if(GPSEnabled){
            Location l = locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER);

            if (l != null){
                init_lat = l.getLatitude();
                init_long = l.getLongitude();
            }


            locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 2000, 2, (LocationListener) this);

        }else{
            Toast.makeText(this, "Please enable location services", Toast.LENGTH_SHORT).show();

        }

    }

    public void onResume() {
        super.onResume();
        if (light != null) {
            sensormanager.registerListener(this, light, SensorManager.SENSOR_DELAY_NORMAL);
        }
    }
    public void onPause(){
        super.onPause();
        sensormanager.unregisterListener(this);
    }

    @Override
    public void onSensorChanged(SensorEvent sensorEvent) {
        getlightdata(sensorEvent);
    }

    private void getlightdata(SensorEvent sensorEvent) {
        Sensor sensor = sensorEvent.sensor;
        if(sensor.getType() == Sensor.TYPE_LIGHT) {
            x = sensorEvent.values[0];
        }
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int i) {

    }

    @Override
    public void onLocationChanged(Location location) {

        String city = null;
        String country = null;
        String location1 = null;

        float new_sensor_value;
        float avg = 0;
        double latitude = location.getLatitude();
        double longitude = location.getLongitude();
        double altitude = location.getAltitude();
        new_sensor_value = x;

        float[] results = new float[10];
        Location.distanceBetween(init_lat, init_long, latitude, longitude, results);
        float distance = results[0];

        if(distance < 7) {
            //averaging the sensor data.
            counter += 1;
            //avg = (init_sensor_value + new_sensor_value) / counter;
            init_sensor_value = init_sensor_value + new_sensor_value;
        } else{

            if(init_sensor_value != 0){
                avg = init_sensor_value/counter;
                text.append("\nAverage: "+avg+"\n\n");
                counter = 0;
                init_sensor_value = 0;
            }
            init_lat = location.getLatitude();
            init_long = location.getLongitude();

            counter += 1;
           // avg = (init_sensor_value + new_sensor_value) / counter;
            init_sensor_value = init_sensor_value + new_sensor_value;

        }


        try {
            Geocoder geocoder = new Geocoder(this);
            List<Address> addresses = null;
            addresses = geocoder.getFromLocation(latitude, longitude, 1);
            country = addresses.get(0).getCountryName();
            city = addresses.get(0).getLocality();
            location1 = addresses.get(0).getThoroughfare();
        } catch (IOException e){
            e.printStackTrace();
            Toast.makeText(this, "Error:" + e, Toast.LENGTH_SHORT).show();
        }

        if(location1 == null){
            location1 = "Not found ";
        }
        if(city == null){
            city = "Not found ";
        }

        if(country == null){
            country = "Not found ";
        }
        text.append("\nLatitude: " +String.valueOf(latitude)+"\nLongitude: "+String.valueOf(longitude)+"\nAltitude: "+
                String.valueOf(altitude)+"\nAddress: "+location1+"\nCity: "+city+"\nCountry: "+country+
                "\nLight Sensor data: "+String.valueOf(x)+"\n");

                //+ "\nAverage"+ String.valueOf(avg)+"\nCounter: "+ counter +"\n \n" );

    }

    @Override
    public void onStatusChanged(String s, int i, Bundle bundle) {

    }

    @Override
    public void onProviderEnabled(String s) {

    }

    @Override
    public void onProviderDisabled(String s) {

    }
}
