package com.example.stepcountermonitor;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.FileProvider;

import android.content.Context;
import android.content.Intent;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.io.File;
import java.io.FileOutputStream;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class MainActivity extends AppCompatActivity implements SensorEventListener {
    SensorManager sensorManager;
    Sensor stepcounter;

    StringBuilder data;
    Date starttime, endtime, timetaken;
    TextView textView1, textView2, finalstep;
    boolean running = false;
    boolean flag = true;
    float initialsteptaken, finalsteptaken, finalsteps;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        sensorManager=(SensorManager)getSystemService(Context.SENSOR_SERVICE);
        stepcounter = sensorManager.getDefaultSensor(Sensor.TYPE_STEP_COUNTER);
        textView1 = (TextView)findViewById(R.id.textView1);
        textView2 = (TextView)findViewById(R.id.textView2);
        finalstep = (TextView)findViewById(R.id.textView3);
        data = new StringBuilder();
        starttime = Calendar.getInstance().getTime();
        textView1.setText("Start time: " + String.valueOf(starttime));
        textView2.setText("End time: ");
        data.append("Steps, StartTime, EndTime");
    }

    public void exportsteps(View view){
        try{

            endtime = Calendar.getInstance().getTime();
            textView2.setText("End time: " + String.valueOf(endtime));
            finalsteps = finalsteptaken - initialsteptaken;
            finalstep.setText("Steps taken: " + String.valueOf(finalsteps));
            data.append("\n"+String.valueOf(finalsteps)+","+String.valueOf(starttime)+","+String.valueOf(endtime));
            FileOutputStream out1 = openFileOutput("steps.csv", Context.MODE_PRIVATE);
            out1.write((data.toString().getBytes()));
            out1.close();


            Context context = getApplicationContext();
            File filelocation1 = new File(getFilesDir(), "steps.csv");
            Uri path = FileProvider.getUriForFile(context, "com.example.stepcountermonitoring.fileprovider", filelocation1);
            Intent intent = new Intent(Intent.ACTION_SEND);
            intent.setType("text/csv");
            intent.putExtra(Intent.EXTRA_SUBJECT, "Data");
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            intent.putExtra(Intent.EXTRA_STREAM, path);
            startActivity(Intent.createChooser(intent, "Send mail"));
        }
        catch (Exception e){
            e.printStackTrace();
        }
    }

    public  void onResume() {
        super.onResume();
        running = true;
        if (stepcounter != null) {
            sensorManager.registerListener(this, stepcounter, SensorManager.SENSOR_DELAY_NORMAL);
        }
    }
    public void onPause() {
        super.onPause();
        running = false;

        sensorManager.unregisterListener(this );
    }


    @Override
    public void onSensorChanged(SensorEvent event) {
        Sensor sensor = event.sensor;

        Calendar calendar = Calendar.getInstance();
        SimpleDateFormat mdformat = new SimpleDateFormat("HH:mm:ss");
        String strDate = mdformat.format(calendar.getTime());




        if(flag == true){
          initialsteptaken = event.values[0];
          flag = false;
        }
        //currentTime = Calendar.getInstance().getTime();
        if(sensor.getType() == Sensor.TYPE_STEP_COUNTER){
            //data.append("\n"+String.valueOf(event.values[0])+","+String.valueOf(strDate));
            finalsteptaken = event.values[0];
        }
        finalsteps = finalsteptaken - initialsteptaken;
        finalstep.setText("Steps taken: " + String.valueOf(finalsteps));
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {

    }
}
