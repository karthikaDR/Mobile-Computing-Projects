package com.example.magic8flip;

        import androidx.appcompat.app.AppCompatActivity;

        import android.content.res.Resources;
        import android.content.res.TypedArray;
        import android.hardware.Sensor;
        import android.hardware.SensorEvent;
        import android.hardware.SensorEventListener;
        import android.hardware.SensorManager;
        import android.os.Bundle;
        import android.view.animation.AlphaAnimation;
        import android.view.animation.Animation;
        import android.view.animation.AnimationUtils;
        import android.widget.LinearLayout;
        import android.widget.TextView;
        import android.widget.Toast;

        import java.util.Random;

public class MainActivity extends AppCompatActivity implements SensorEventListener {


    Sensor accelerometer;
    SensorManager sm;
    TextView message;
    private float lastx;
    private float lasty;
    private float lastz;
    private float currentx;
    private float currenty;
    private float currentz;

    TextView x,y,z,x3,y3,z3;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        sm = (SensorManager) getSystemService(SENSOR_SERVICE);
        accelerometer = sm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
        message = (TextView)findViewById(R.id.msg);
        TextView myText = (TextView) findViewById(R.id.heading);

        x = (TextView)findViewById(R.id.x);
        y = (TextView)findViewById(R.id.y);
        z = (TextView)findViewById(R.id.z);
        x3 = (TextView)findViewById(R.id.x3);
        y3 = (TextView)findViewById(R.id.y3);
        z3 = (TextView)findViewById(R.id.z3);

        /*Animation anim = new AlphaAnimation(0.0f, 1.0f);
        anim.setDuration(50); //You can manage the time of the blink with this parameter
        anim.setStartOffset(10);
        anim.setRepeatMode(Animation.REVERSE);
        anim.setRepeatCount(Animation.INFINITE);
        myText.startAnimation(anim);*/
    }

    public void onResume(){
        super.onResume();
        sm.registerListener(this, accelerometer, SensorManager.SENSOR_DELAY_NORMAL);
    }
    public void onPause() {
        super.onPause();
        sm.unregisterListener(this);
    }
    @Override
    public void onSensorChanged(SensorEvent sensorEvent) {

        float delx;
        float dely;
        float delz;
        float delchange;

        lastx = currentx;
        lasty = currenty;
        lastz = currentz;

        currentx = sensorEvent.values[0];
        currenty = sensorEvent.values[1];
        currentz = sensorEvent.values[2];

        delx = Math.abs(currentx - lastx);
        dely = Math.abs(currenty - lasty);
        delz = Math.abs(currentz - lastz);

//        x3.setText(String.valueOf(delx));
//        y3.setText(String.valueOf(dely));
//        z3.setText(String.valueOf(delz));


        final LinearLayout bg = (LinearLayout)findViewById(R.id.back);
        Resources res = getResources();
        final TypedArray myImages = res.obtainTypedArray(R.array.image);

        String[] names = {"It is certain",
                        "It is decidedly so",
                        "Without a doubt",
                        "Yes definitely",
                        "You may rely on it",
                        "As I see it yes",
                        "Most likely",
                        "Outlook good",
                        "Yes",
                        "Signs point to yes",
                        "Reply hazy try again",
                        "Ask again later",
                        "Better not tell you now",
                        "Cannot predict now",
                        "Concentrate and ask again",
                        "Don't count on it",
                        "My reply is no",
                        "My sources say no",
                        "Outlook not so good",
                        "Very doubtful"};
        Random rantext = new Random();
        int num = rantext.nextInt(names.length);
        int bgimage = rantext.nextInt(myImages.length());
        int drawableID = myImages.getResourceId(bgimage, -1);
        final Animation myAnim = AnimationUtils.loadAnimation(this, R.anim.anim);


        if (currentz < -6 && delz > 1.8) {

            message.setText(names[num]);
            bg.setBackgroundResource(drawableID);
            message.startAnimation(myAnim);

        }

    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int i) {

    }
}
